package com.example.app1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                if (email.equals("admin@admin.ru") && password.equals("123")) {
                    intent.putExtra("message", getString(R.string.welcome));
                } else {
                    intent.putExtra("message", getString(R.string.auth_failed));
                }
                startActivity(intent);
            }
        });
    }
}
